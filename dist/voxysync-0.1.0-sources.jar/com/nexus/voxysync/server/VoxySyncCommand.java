package com.nexus.voxysync.server;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.nexus.voxysync.VoxySyncConfig;
import com.nexus.voxysync.VoxySyncMod;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.nio.file.Path;
import java.util.UUID;

/**
 * /voxysync 管理命令（需要 OP，权限等级 2）。
 *
 * <pre>
 * /voxysync status                 查看当前配置与进行中的同步
 * /voxysync enable | disable       开关服务端同步
 * /voxysync mode radius|all        切换模式（all = 全图，注意安全警告）
 * /voxysync radius &lt;blocks&gt;        设置 radius 模式的半径（方块）
 * /voxysync sync [radius|all]      让<b>自己</b>立即重新同步一次（可临时指定模式）
 * /voxysync devtest [mode] [radius] 只读诊断（/tmp 测试实例无客户端验证用）
 * </pre>
 */
public final class VoxySyncCommand {
    private static final SuggestionProvider<class_2168> MODE_SUGGESTIONS =
            (context, builder) -> net.minecraft.class_2172.method_9253(
                    new String[]{"radius", "all"}, builder);

    private VoxySyncCommand() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(class_2170.method_9247("voxysync").requires(source -> source.method_9259(2))
                        .then(class_2170.method_9247("status").executes(VoxySyncCommand::status))
                        .then(class_2170.method_9247("enable").executes(ctx -> setEnabled(ctx, true)))
                        .then(class_2170.method_9247("disable").executes(ctx -> setEnabled(ctx, false)))
                        .then(class_2170.method_9247("mode")
                                .then(class_2170.method_9244("mode", StringArgumentType.word())
                                        .suggests(MODE_SUGGESTIONS)
                                        .executes(VoxySyncCommand::setMode)))
                        .then(class_2170.method_9247("radius")
                                .then(class_2170.method_9244("blocks", IntegerArgumentType.integer(64, 100000))
                                        .executes(VoxySyncCommand::setRadius)))
                        .then(class_2170.method_9247("sync")
                                .executes(ctx -> syncSelf(ctx, null))
                                .then(class_2170.method_9244("mode", StringArgumentType.word())
                                        .suggests(MODE_SUGGESTIONS)
                                        .executes(ctx -> syncSelf(ctx, StringArgumentType.getString(ctx, "mode")))))
                        .then(class_2170.method_9247("devtest")
                                .executes(ctx -> devtest(ctx, null, -1))
                                .then(class_2170.method_9244("mode", StringArgumentType.word())
                                        .suggests(MODE_SUGGESTIONS)
                                        .executes(ctx -> devtest(ctx, StringArgumentType.getString(ctx, "mode"), -1))
                                        .then(class_2170.method_9244("radius", IntegerArgumentType.integer(64, 100000))
                                                .executes(ctx -> devtest(ctx,
                                                        StringArgumentType.getString(ctx, "mode"),
                                                        IntegerArgumentType.getInteger(ctx, "radius"))))))
                ));
    }

    private static int status(CommandContext<class_2168> ctx) {
        VoxySyncConfig.Config cfg = VoxySyncConfig.INSTANCE;
        String modeText = "all".equals(cfg.syncMode)
                ? "§c全图 (all)§r —— 发送整个维度，数据可能暴露箱子/矿脉/地下结构!"
                : "radius（半径 " + cfg.radiusBlocks + " 方块）";
        ctx.getSource().method_9226(() -> class_2561.method_43470("§6[VoxySync]§r 状态：")
                .method_27693("\n  · 同步开关: " + (cfg.enableVoxySync ? "§a开启§r" : "§c关闭§r"))
                .method_27693("\n  · 模式: " + modeText)
                .method_27693("\n  · 限速: " + cfg.speedLimitKBps + " KB/s（≤0 不限速）")
                .method_27693("\n  · 分片大小: " + cfg.maxPacketSize + " 字节")
                .method_27693("\n  · 进行中的同步: " + VoxySyncHandler.getActiveSyncCount() + " 个")
                .method_27693("\n  · 配置: config/voxysync.json"), true);
        return 1;
    }

    private static int setEnabled(CommandContext<class_2168> ctx, boolean enabled) {
        VoxySyncConfig.INSTANCE.enableVoxySync = enabled;
        VoxySyncConfig.save();
        VoxySyncHandler.logSecurityWarningIfEnabled();
        ctx.getSource().method_9226(() -> class_2561.method_43470("§6[VoxySync]§r 同步已"
                + (enabled ? "§a开启§r（模式: " + VoxySyncConfig.INSTANCE.syncMode + "）" : "§c关闭§r")), true);
        return 1;
    }

    private static int setMode(CommandContext<class_2168> ctx) {
        String mode = StringArgumentType.getString(ctx, "mode");
        if (!"radius".equals(mode) && !"all".equals(mode)) {
            ctx.getSource().method_9213(class_2561.method_43470("§c模式只能是 radius 或 all"));
            return 0;
        }
        VoxySyncConfig.INSTANCE.syncMode = mode;
        VoxySyncConfig.save();
        if ("all".equals(mode)) {
            VoxySyncMod.LOGGER.warn("[VoxySync] 已切换为全图模式(all)：发送完整 MCA 区域文件，"
                    + "可暴露箱子内容/实体/矿脉/隐藏结构，仅建议在信任的服务器使用！");
            ctx.getSource().method_9226(() -> class_2561.method_43470("§6[VoxySync]§r 已切换为 §c全图模式(all)§r。"
                    + "警告：MCA 数据可暴露箱子内容、实体、矿脉与隐藏结构，仅建议在信任的服务器使用！"), true);
        } else {
            ctx.getSource().method_9226(() -> class_2561.method_43470("§6[VoxySync]§r 已切换为 radius 模式（半径 "
                    + VoxySyncConfig.INSTANCE.radiusBlocks + " 方块）"), true);
        }
        return 1;
    }

    private static int setRadius(CommandContext<class_2168> ctx) {
        int blocks = IntegerArgumentType.getInteger(ctx, "blocks");
        VoxySyncConfig.INSTANCE.radiusBlocks = blocks;
        VoxySyncConfig.save();
        ctx.getSource().method_9226(() -> class_2561.method_43470("§6[VoxySync]§r radius 半径已设为 "
                + blocks + " 方块"), true);
        return 1;
    }

    private static int syncSelf(CommandContext<class_2168> ctx, String mode) {
        class_3222 player;
        try {
            player = ctx.getSource().method_9207();
        } catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("§c该命令只能由在线玩家执行"));
            return 0;
        }
        if (mode != null && !"radius".equals(mode) && !"all".equals(mode)) {
            ctx.getSource().method_9213(class_2561.method_43470("§c模式只能是 radius 或 all"));
            return 0;
        }
        UUID playerId = player.method_5667();
        if (mode != null) {
            VoxySyncHandler.setPendingMode(playerId, mode);
        }
        VoxySyncHandler.requestClientSync(player, mode, "管理员请求重新同步");
        ctx.getSource().method_9226(() -> class_2561.method_43470("§6[VoxySync]§r 已通知客户端重新同步"
                + (mode != null ? "（模式: " + mode + "）" : "（按配置: " + VoxySyncConfig.INSTANCE.syncMode + "）")), true);
        return 1;
    }

    /** 诊断（只读）：无真实客户端时验证区域收集/增量逻辑与编解码 */
    private static int devtest(CommandContext<class_2168> ctx, String mode, int radius) {
        class_3218 world = ctx.getSource().method_9225();
        int cx = world.method_43126().method_10263();
        int cz = world.method_43126().method_10260();
        if (mode == null) {
            mode = VoxySyncConfig.INSTANCE.syncMode;
        }
        String out = VoxySyncHandler.diagCollect(world, cx, cz, mode, radius);
        ctx.getSource().method_9226(() -> class_2561.method_43470(out), true);
        ctx.getSource().method_9226(() -> class_2561.method_43470("编解码测试: " + VoxySyncHandler.diagCodec()), true);
        Path regionDir = VoxySyncHandler.resolveRegionDir(world);
        if (regionDir != null) {
            ctx.getSource().method_9226(() -> class_2561.method_43470("文件校验: " + VoxySyncHandler.diagFileRead(regionDir)), true);
        }
        return 1;
    }
}
