package com.nexus.voxysync.network;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * 网络通道定义与载荷编解码（Minecraft 1.20.1 Fabric 经典 ResourceLocation + FriendlyByteBuf 风格）。
 *
 * <p>协议流程（C2S/S2C 均为 1.20.1 自定义载荷；注意 C2S 上限 32767 字节、S2C 上限 1048576 字节）：</p>
 * <ol>
 *   <li>C→S capability_request：客户端探测服务器是否启用同步。</li>
 *   <li>S→C capability(enabled, reason)：返回开关状态。</li>
 *   <li>C→S sync_request(分块)：请求同步当前维度；每块携带文件名→(时间戳/大小) 元数据（增量）。</li>
 *   <li>S→C sync_start(syncId, dimensionId, totalRegions, totalBytes)。</li>
 *   <li>S→C region_part(...) 若干次（限速分片）。</li>
 *   <li>S→C sync_progress(...)（每个区域完成后）。</li>
 *   <li>S→C sync_complete(syncId, success, message, transferredRegions, transferredBytes)。</li>
 *   <li>S→C request_sync(modeHint)：OP 用 /voxysync sync 命令提示客户端立刻发起同步。</li>
 * </ol>
 */
public final class VoxyPackets {
    public static final class_2960 CAPABILITY_REQUEST = new class_2960("voxysync", "capability_request");
    public static final class_2960 CAPABILITY = new class_2960("voxysync", "capability");
    public static final class_2960 SYNC_REQUEST = new class_2960("voxysync", "sync_request");
    public static final class_2960 SYNC_START = new class_2960("voxysync", "sync_start");
    public static final class_2960 REGION_PART = new class_2960("voxysync", "region_part");
    public static final class_2960 SYNC_PROGRESS = new class_2960("voxysync", "sync_progress");
    public static final class_2960 SYNC_COMPLETE = new class_2960("voxysync", "sync_complete");
    public static final class_2960 REQUEST_SYNC = new class_2960("voxysync", "request_sync");

    /** 字符串字段最大长度（防异常包占满内存） */
    public static final int MAX_STRING = 256;
    /** 客户端元数据总条数上限 */
    public static final int MAX_META_ENTRIES = 20000;
    /** 每个 sync_request 块携带的元数据条数上限 */
    public static final int MAX_ENTRIES_PER_CHUNK = 300;
    /** sync_request 分块数上限 */
    public static final int MAX_CHUNKS = 64;

    private VoxyPackets() {
    }

    /** 区域元数据（用于增量判断：时间戳 + 大小均一致则视为未变化） */
    public record RegionMeta(long timestampSeconds, long sizeBytes) {
        public void encode(class_2540 buf) {
            buf.writeLong(this.timestampSeconds);
            buf.writeLong(this.sizeBytes);
        }

        public static RegionMeta decode(class_2540 buf) {
            return new RegionMeta(buf.readLong(), buf.readLong());
        }
    }

    /** 服务器能力（是否已启用 + 原因/模式说明） */
    public record CapabilityPayload(boolean enabled, String reason) {
        public void encode(class_2540 buf) {
            buf.writeBoolean(this.enabled);
            buf.method_10788(this.reason, 64);
        }

        public static CapabilityPayload decode(class_2540 buf) {
            return new CapabilityPayload(buf.readBoolean(), buf.method_10800(64));
        }
    }

    /**
     * 同步请求（客户端 → 服务端，按块发送：1.20.1 C2S 自定义载荷上限 32767 字节）。
     *
     * @param dimensionId 当前维度 id（ResourceLocation of dimension key）
     * @param requestId   本次请求的随机 id（服务端聚合判据）
     * @param chunkIndex  第几块（0 起）
     * @param totalChunks 总块数
     * @param entries     本块的元数据（key = fileName，不含维度前缀）
     */
    public record SyncRequestPayload(String dimensionId, String requestId, int chunkIndex, int totalChunks,
                                     Map<String, RegionMeta> entries) {
        public void encode(class_2540 buf) {
            buf.method_10788(this.dimensionId, MAX_STRING);
            buf.method_10788(this.requestId, 36);
            buf.writeInt(this.chunkIndex);
            buf.writeInt(this.totalChunks);
            buf.writeInt(this.entries.size());
            for (Map.Entry<String, RegionMeta> entry : this.entries.entrySet()) {
                buf.method_10788(entry.getKey(), 64);
                entry.getValue().encode(buf);
            }
        }

        public static SyncRequestPayload decode(class_2540 buf) {
            String dimensionId = buf.method_10800(MAX_STRING);
            String requestId = buf.method_10800(36);
            int chunkIndex = Math.max(buf.readInt(), 0);
            int totalChunks = Math.min(Math.max(buf.readInt(), 1), MAX_CHUNKS);
            int size = Math.min(Math.max(buf.readInt(), 0), MAX_ENTRIES_PER_CHUNK);
            Map<String, RegionMeta> meta = new HashMap<>();
            for (int i = 0; i < size; i++) {
                meta.put(buf.method_10800(64), RegionMeta.decode(buf));
            }
            return new SyncRequestPayload(dimensionId, requestId, chunkIndex, totalChunks, meta);
        }
    }

    /** 同步开始（服务端 → 客户端） */
    public record SyncStartPayload(String syncId, String dimensionId, int totalRegions, long totalBytes) {
        public void encode(class_2540 buf) {
            buf.method_10788(this.syncId, MAX_STRING);
            buf.method_10788(this.dimensionId, MAX_STRING);
            buf.writeInt(this.totalRegions);
            buf.writeLong(this.totalBytes);
        }

        public static SyncStartPayload decode(class_2540 buf) {
            return new SyncStartPayload(buf.method_10800(MAX_STRING), buf.method_10800(MAX_STRING),
                    buf.readInt(), buf.readLong());
        }
    }

    /** 区域文件分片（服务端 → 客户端） */
    public record RegionPartPayload(String syncId, String dimensionId, int regionX, int regionZ,
                                    int partIndex, int totalParts, long byteOffset, long totalBytes,
                                    long timestampSeconds, byte[] data) {
        public void encode(class_2540 buf) {
            buf.method_10788(this.syncId, MAX_STRING);
            buf.method_10788(this.dimensionId, MAX_STRING);
            buf.writeInt(this.regionX);
            buf.writeInt(this.regionZ);
            buf.writeInt(this.partIndex);
            buf.writeInt(this.totalParts);
            buf.writeLong(this.byteOffset);
            buf.writeLong(this.totalBytes);
            buf.writeLong(this.timestampSeconds);
            buf.method_10813(this.data);
        }

        public static RegionPartPayload decode(class_2540 buf) {
            return new RegionPartPayload(buf.method_10800(MAX_STRING), buf.method_10800(MAX_STRING),
                    buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(),
                    buf.readLong(), buf.readLong(), buf.readLong(), buf.method_10795());
        }
    }

    /** 同步进度（服务端 → 客户端） */
    public record SyncProgressPayload(String syncId, int processedRegions, int totalRegions,
                                      long processedBytes, long totalBytes, String status) {
        public void encode(class_2540 buf) {
            buf.method_10788(this.syncId, MAX_STRING);
            buf.writeInt(this.processedRegions);
            buf.writeInt(this.totalRegions);
            buf.writeLong(this.processedBytes);
            buf.writeLong(this.totalBytes);
            buf.method_10788(this.status, 64);
        }

        public static SyncProgressPayload decode(class_2540 buf) {
            return new SyncProgressPayload(buf.method_10800(MAX_STRING), buf.readInt(), buf.readInt(),
                    buf.readLong(), buf.readLong(), buf.method_10800(64));
        }
    }

    /** 同步完成/失败（服务端 → 客户端） */
    public record SyncCompletePayload(String syncId, boolean success, String message,
                                      int transferredRegions, long transferredBytes) {
        public void encode(class_2540 buf) {
            buf.method_10788(this.syncId, MAX_STRING);
            buf.writeBoolean(this.success);
            buf.method_10788(this.message, MAX_STRING);
            buf.writeInt(this.transferredRegions);
            buf.writeLong(this.transferredBytes);
        }

        public static SyncCompletePayload decode(class_2540 buf) {
            return new SyncCompletePayload(buf.method_10800(MAX_STRING), buf.readBoolean(),
                    buf.method_10800(MAX_STRING), buf.readInt(), buf.readLong());
        }
    }

    /** 服务端请求客户端立刻发起同步（OP 命令用；modeHint = radius/all/空串按配置） */
    public record RequestSyncPayload(String modeHint, String note) {
        public void encode(class_2540 buf) {
            buf.method_10788(this.modeHint == null ? "" : this.modeHint, 16);
            buf.method_10788(this.note == null ? "" : this.note, MAX_STRING);
        }

        public static RequestSyncPayload decode(class_2540 buf) {
            return new RequestSyncPayload(buf.method_10800(16), buf.method_10800(MAX_STRING));
        }
    }
}
