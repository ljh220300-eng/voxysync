package com.nexus.voxysync.client.voxy;

import java.nio.file.Path;
import net.minecraft.class_310;

/**
 * Voxy 桥接接口（保留可替换接口：将来 Voxy 官方支持 1.20.1 或改版时只需换实现）。
 * 改编自 MapSyncer-rebuild（GPL-3.0）。
 */
public interface IVoxyBridge {
    boolean isAvailable(class_310 client);

    boolean startImport(class_310 client, Path regionDirectory) throws Exception;
}
